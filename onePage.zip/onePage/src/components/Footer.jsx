import React from "react";

function Footer() {
  return (
    <div id="">
      <div className="s-heading">
        <p>CopyRight 2024</p>
      </div>
    </div>
  );
}

export default Footer;
